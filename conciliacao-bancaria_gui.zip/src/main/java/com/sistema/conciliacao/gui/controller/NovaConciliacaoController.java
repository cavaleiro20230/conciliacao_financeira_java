package com.sistema.conciliacao.gui.controller;

import com.sistema.conciliacao.gui.model.ConciliacaoTableModel;
import com.sistema.conciliacao.gui.util.AlertUtil;
import com.sistema.conciliacao.model.*;
import com.sistema.conciliacao.service.ConciliacaoService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class NovaConciliacaoController implements Initializable {
    
    @FXML private TextField txtContaBancaria;
    @FXML private TextField txtAgencia;
    @FXML private DatePicker dpDataInicio;
    @FXML private DatePicker dpDataFim;
    @FXML private Button btnExecutarConciliacao;
    @FXML private Button btnCancelar;
    
    @FXML private TabPane tabPaneConciliacao;
    @FXML private Tab tabResumo;
    @FXML private Tab tabConciliados;
    @FXML private Tab tabNaoConciliados;
    
    // Resumo
    @FXML private Label lblSaldoBanco;
    @FXML private Label lblSaldoInterno;
    @FXML private Label lblDiferenca;
    @FXML private Label lblTotalConciliados;
    @FXML private Label lblTotalNaoConciliados;
    @FXML private ProgressBar progressConciliacao;
    
    // Tabela de itens conciliados
    @FXML private TableView<ConciliacaoTableModel> tblItensConciliados;
    @FXML private TableColumn<ConciliacaoTableModel, LocalDate> colDataConciliado;
    @FXML private TableColumn<ConciliacaoTableModel, String> colDescricaoConciliado;
    @FXML private TableColumn<ConciliacaoTableModel, BigDecimal> colValorConciliado;
    @FXML private TableColumn<ConciliacaoTableModel, String> colTipoMatch;
    @FXML private TableColumn<ConciliacaoTableModel, BigDecimal> colDiferenca;
    
    // Tabela de itens não conciliados
    @FXML private TableView<ConciliacaoTableModel> tblItensNaoConciliados;
    @FXML private TableColumn<ConciliacaoTableModel, LocalDate> colDataNaoConciliado;
    @FXML private TableColumn<ConciliacaoTableModel, String> colDescricaoNaoConciliado;
    @FXML private TableColumn<ConciliacaoTableModel, BigDecimal> colValorNaoConciliado;
    @FXML private TableColumn<ConciliacaoTableModel, String> colOrigemNaoConciliado;
    
    @FXML private Button btnConciliarManual;
    @FXML private Button btnDesconciliar;
    @FXML private Button btnSalvarConciliacao;
    
    private ConciliacaoService conciliacaoService;
    private Conciliacao conciliacaoAtual;
    private ObservableList<ConciliacaoTableModel> itensConciliados;
    private ObservableList<ConciliacaoTableModel> itensNaoConciliados;
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        conciliacaoService = new ConciliacaoService();
        itensConciliados = FXCollections.observableArrayList();
        itensNaoConciliados = FXCollections.observableArrayList();
        
        configurarTabelas();
        configurarEventos();
        inicializarCampos();
    }
    
    private void configurarTabelas() {
        // Tabela de conciliados
        colDataConciliado.setCellValueFactory(new PropertyValueFactory<>("data"));
        colDescricaoConciliado.setCellValueFactory(new PropertyValueFactory<>("descricao"));
        colValorConciliado.setCellValueFactory(new PropertyValueFactory<>("valor"));
        colTipoMatch.setCellValueFactory(new PropertyValueFactory<>("tipoMatch"));
        colDiferenca.setCellValueFactory(new PropertyValueFactory<>("diferenca"));
        
        tblItensConciliados.setItems(itensConciliados);
        
        // Tabela de não conciliados
        colDataNaoConciliado.setCellValueFactory(new PropertyValueFactory<>("data"));
        colDescricaoNaoConciliado.setCellValueFactory(new PropertyValueFactory<>("descricao"));
        colValorNaoConciliado.setCellValueFactory(new PropertyValueFactory<>("valor"));
        colOrigemNaoConciliado.setCellValueFactory(new PropertyValueFactory<>("origem"));
        
        tblItensNaoConciliados.setItems(itensNaoConciliados);
        
        // Formatação de valores monetários
        configurarFormatacaoMonetaria();
    }
    
    private void configurarFormatacaoMonetaria() {
        colValorConciliado.setCellFactory(col -> new TableCell<ConciliacaoTableModel, BigDecimal>() {
            @Override
            protected void updateItem(BigDecimal item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(String.format("R$ %,.2f", item));
                }
            }
        });
        
        colDiferenca.setCellFactory(col -> new TableCell<ConciliacaoTableModel, BigDecimal>() {
            @Override
            protected void updateItem(BigDecimal item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(String.format("R$ %,.2f", item));
                    if (item.compareTo(BigDecimal.ZERO) != 0) {
                        setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
                    } else {
                        setStyle("-fx-text-fill: green;");
                    }
                }
            }
        });
        
        colValorNaoConciliado.setCellFactory(col -> new TableCell<ConciliacaoTableModel, BigDecimal>() {
            @Override
            protected void updateItem(BigDecimal item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(String.format("R$ %,.2f", item));
                }
            }
        });
    }
    
    private void configurarEventos() {
        btnExecutarConciliacao.setOnAction(e -> executarConciliacao());
        btnCancelar.setOnAction(e -> fecharJanela());
        btnConciliarManual.setOnAction(e -> abrirConciliacaoManual());
        btnDesconciliar.setOnAction(e -> desconciliarItem());
        btnSalvarConciliacao.setOnAction(e -> salvarConciliacao());
        
        // Habilitar/desabilitar botões baseado na seleção
        tblItensConciliados.getSelectionModel().selectedItemProperty().addListener(
            (obs, oldSelection, newSelection) -> btnDesconciliar.setDisable(newSelection == null)
        );
        
        tblItensNaoConciliados.getSelectionModel().selectedItemProperty().addListener(
            (obs, oldSelection, newSelection) -> btnConciliarManual.setDisable(newSelection == null)
        );
    }
    
    private void inicializarCampos() {
        dpDataInicio.setValue(LocalDate.now().withDayOfMonth(1));
        dpDataFim.setValue(LocalDate.now());
        tabPaneConciliacao.setDisable(true);
        btnSalvarConciliacao.setDisable(true);
    }
    
    @FXML
    private void executarConciliacao() {
        if (!validarCampos()) {
            return;
        }
        
        btnExecutarConciliacao.setDisable(true);
        progressConciliacao.setVisible(true);
        
        Task<Conciliacao> task = new Task<Conciliacao>() {
            @Override
            protected Conciliacao call() throws Exception {
                // Simular dados para demonstração
                List<LancamentoBancario> lancamentosBanco = criarLancamentosExemplo();
                List<RegistroInterno> registrosInternos = criarRegistrosExemplo();
                
                updateProgress(0.3, 1.0);
                Thread.sleep(1000); // Simular processamento
                
                Conciliacao conciliacao = conciliacaoService.executarConciliacao(
                    lancamentosBanco,
                    registrosInternos,
                    txtContaBancaria.getText(),
                    txtAgencia.getText(),
                    dpDataInicio.getValue(),
                    dpDataFim.getValue()
                );
                
                updateProgress(1.0, 1.0);
                return conciliacao;
            }
            
            @Override
            protected void succeeded() {
                conciliacaoAtual = getValue();
                atualizarInterface();
                btnExecutarConciliacao.setDisable(false);
                progressConciliacao.setVisible(false);
                tabPaneConciliacao.setDisable(false);
                btnSalvarConciliacao.setDisable(false);
                
                AlertUtil.mostrarInformacao("Sucesso", "Conciliação executada com sucesso!");
            }
            
            @Override
            protected void failed() {
                btnExecutarConciliacao.setDisable(false);
                progressConciliacao.setVisible(false);
                AlertUtil.mostrarErro("Erro", "Erro ao executar conciliação", getException().getMessage());
            }
        };
        
        progressConciliacao.progressProperty().bind(task.progressProperty());
        new Thread(task).start();
    }
    
    private boolean validarCampos() {
        if (txtContaBancaria.getText().trim().isEmpty()) {
            AlertUtil.mostrarAviso("Validação", "Informe o número da conta bancária.");
            txtContaBancaria.requestFocus();
            return false;
        }
        
        if (txtAgencia.getText().trim().isEmpty()) {
            AlertUtil.mostrarAviso("Validação", "Informe o número da agência.");
            txtAgencia.requestFocus();
            return false;
        }
        
        if (dpDataInicio.getValue() == null) {
            AlertUtil.mostrarAviso("Validação", "Informe a data de início.");
            dpDataInicio.requestFocus();
            return false;
        }
        
        if (dpDataFim.getValue() == null) {
            AlertUtil.mostrarAviso("Validação", "Informe a data de fim.");
            dpDataFim.requestFocus();
            return false;
        }
        
        if (dpDataInicio.getValue().isAfter(dpDataFim.getValue())) {
            AlertUtil.mostrarAviso("Validação", "A data de início deve ser anterior à data de fim.");
            dpDataInicio.requestFocus();
            return false;
        }
        
        return true;
    }
    
    private void atualizarInterface() {
        if (conciliacaoAtual == null) return;
        
        // Atualizar resumo
        lblSaldoBanco.setText(String.format("R$ %,.2f", conciliacaoAtual.getSaldoFinalBanco()));
        lblSaldoInterno.setText(String.format("R$ %,.2f", conciliacaoAtual.getSaldoFinalInterno()));
        lblDiferenca.setText(String.format("R$ %,.2f", conciliacaoAtual.getDiferenca()));
        lblTotalConciliados.setText(String.valueOf(conciliacaoAtual.getTotalItensConciliados()));
        lblTotalNaoConciliados.setText(String.valueOf(conciliacaoAtual.getTotalItensNaoConciliados()));
        
        // Atualizar tabelas
        atualizarTabelaConciliados();
        atualizarTabelaNaoConciliados();
        
        // Calcular e exibir progresso
        double percentual = (double) conciliacaoAtual.getTotalItensConciliados() / 
                           (conciliacaoAtual.getTotalItensConciliados() + conciliacaoAtual.getTotalItensNaoConciliados());
        progressConciliacao.setProgress(percentual);
    }
    
    private void atualizarTabelaConciliados() {
        itensConciliados.clear();
        
        for (ItemConciliado item : conciliacaoAtual.getItensConciliados()) {
            ConciliacaoTableModel model = new ConciliacaoTableModel();
            model.setData(item.getLancamentoBancario().getDataLancamento());
            model.setDescricao(item.getLancamentoBancario().getHistorico());
            model.setValor(item.getLancamentoBancario().getValor());
            model.setTipoMatch(item.getTipoCorrespondencia().getDescricao());
            model.setDiferenca(item.getDiferenca());
            model.setOrigem("Conciliado");
            
            itensConciliados.add(model);
        }
    }
    
    private void atualizarTabelaNaoConciliados() {
        itensNaoConciliados.clear();
        
        // Lançamentos bancários não conciliados
        for (LancamentoBancario lancamento : conciliacaoAtual.getLancamentosNaoConciliadosBanco()) {
            ConciliacaoTableModel model = new ConciliacaoTableModel();
            model.setData(lancamento.getDataLancamento());
            model.setDescricao(lancamento.getHistorico());
            model.setValor(lancamento.getValor());
            model.setOrigem("Banco");
            
            itensNaoConciliados.add(model);
        }
        
        // Registros internos não conciliados
        for (RegistroInterno registro : conciliacaoAtual.getRegistrosNaoConciliadosInterno()) {
            ConciliacaoTableModel model = new ConciliacaoTableModel();
            model.setData(registro.getDataRegistro());
            model.setDescricao(registro.getDescricao());
            model.setValor(registro.getValor());
            model.setOrigem("Interno");
            
            itensNaoConciliados.add(model);
        }
    }
    
    @FXML
    private void abrirConciliacaoManual() {
        ConciliacaoTableModel itemSelecionado = tblItensNaoConciliados.getSelectionModel().getSelectedItem();
        if (itemSelecionado == null) {
            AlertUtil.mostrarAviso("Seleção", "Selecione um item para conciliar manualmente.");
            return;
        }
        
        // Aqui você abriria uma janela de conciliação manual
        AlertUtil.mostrarInformacao("Conciliação Manual", 
            "Funcionalidade de conciliação manual será implementada em uma janela específica.");
    }
    
    @FXML
    private void desconciliarItem() {
        ConciliacaoTableModel itemSelecionado = tblItensConciliados.getSelectionModel().getSelectedItem();
        if (itemSelecionado == null) {
            AlertUtil.mostrarAviso("Seleção", "Selecione um item para desconciliar.");
            return;
        }
        
        if (AlertUtil.mostrarConfirmacao("Desconciliar", 
            "Deseja realmente desconciliar este item?")) {
            
            // Implementar lógica de desconciliação
            AlertUtil.mostrarInformacao("Desconciliação", "Item desconciliado com sucesso!");
            atualizarInterface();
        }
    }
    
    @FXML
    private void salvarConciliacao() {
        if (conciliacaoAtual == null) {
            AlertUtil.mostrarAviso("Validação", "Execute a conciliação antes de salvar.");
            return;
        }
        
        if (AlertUtil.mostrarConfirmacao("Salvar", 
            "Deseja salvar esta conciliação?")) {
            
            // Implementar lógica de salvamento
            AlertUtil.mostrarInformacao("Sucesso", "Conciliação salva com sucesso!");
            fecharJanela();
        }
    }
    
    private void fecharJanela() {
        Stage stage = (Stage) btnCancelar.getScene().getWindow();
        stage.close();
    }
    
    // Métodos para criar dados de exemplo
    private List<LancamentoBancario> criarLancamentosExemplo() {
        List<LancamentoBancario> lancamentos = new ArrayList<>();
        
        lancamentos.add(new LancamentoBancario("1", LocalDate.now().minusDays(5), 
            "PAGAMENTO PIX", new BigDecimal("1500.00"), TipoTransacao.DEBITO, "0001", "12345-6"));
        
        lancamentos.add(new LancamentoBancario("2", LocalDate.now().minusDays(3), 
            "DEPOSITO EM CONTA", new BigDecimal("2000.00"), TipoTransacao.CREDITO, "0001", "12345-6"));
        
        lancamentos.add(new LancamentoBancario("3", LocalDate.now().minusDays(2), 
            "TED ENVIADA", new BigDecimal("800.00"), TipoTransacao.DEBITO, "0001", "12345-6"));
        
        return lancamentos;
    }
    
    private List<RegistroInterno> criarRegistrosExemplo() {
        List<RegistroInterno> registros = new ArrayList<>();
        
        registros.add(new RegistroInterno(1L, LocalDate.now().minusDays(5), 
            "Pagamento fornecedor via PIX", new BigDecimal("1500.00"), TipoMovimento.PAGAMENTO));
        
        registros.add(new RegistroInterno(2L, LocalDate.now().minusDays(3), 
            "Recebimento cliente", new BigDecimal("2000.00"), TipoMovimento.RECEBIMENTO));
        
        registros.add(new RegistroInterno(3L, LocalDate.now().minusDays(1), 
            "Pagamento não identificado", new BigDecimal("500.00"), TipoMovimento.PAGAMENTO));
        
        return registros;
    }
}
