package com.sistema.conciliacao.gui.controller;

import com.sistema.conciliacao.gui.util.AlertUtil;
import com.sistema.conciliacao.model.LancamentoBancario;
import com.sistema.conciliacao.service.ImportacaoExtratoService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.math.BigDecimal;
import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class ImportacaoExtratoController implements Initializable {
    
    @FXML private TextField txtArquivo;
    @FXML private Button btnProcurar;
    @FXML private ComboBox<String> cbTipoArquivo;
    @FXML private Button btnImportar;
    @FXML private Button btnCancelar;
    @FXML private Button btnSalvar;
    
    @FXML private ProgressBar progressImportacao;
    @FXML private Label lblStatus;
    
    @FXML private TableView<LancamentoBancario> tblLancamentos;
    @FXML private TableColumn<LancamentoBancario, LocalDate> colData;
    @FXML private TableColumn<LancamentoBancario, String> colHistorico;
    @FXML private TableColumn<LancamentoBancario, BigDecimal> colValor;
    @FXML private TableColumn<LancamentoBancario, String> colTipo;
    
    @FXML private Label lblTotalRegistros;
    @FXML private Label lblTotalCreditos;
    @FXML private Label lblTotalDebitos;
    
    private ImportacaoExtratoService importacaoService;
    private ObservableList<LancamentoBancario> lancamentos;
    private File arquivoSelecionado;
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        importacaoService = new ImportacaoExtratoService();
        lancamentos = FXCollections.observableArrayList();
        
        configurarComboBox();
        configurarTabela();
        configurarEventos();
        inicializarInterface();
    }
    
    private void configurarComboBox() {
        cbTipoArquivo.setItems(FXCollections.observableArrayList("CSV", "OFX", "TXT"));
        cbTipoArquivo.setValue("CSV");
    }
    
    private void configurarTabela() {
        colData.setCellValueFactory(new PropertyValueFactory<>("dataLancamento"));
        colHistorico.setCellValueFactory(new PropertyValueFactory<>("historico"));
        colValor.setCellValueFactory(new PropertyValueFactory<>("valor"));
        colTipo.setCellValueFactory(new PropertyValueFactory<>("tipoTransacao"));
        
        // Formatação da coluna de valor
        colValor.setCellFactory(col -> new TableCell<LancamentoBancario, BigDecimal>() {
            @Override
            protected void updateItem(BigDecimal item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(String.format("R$ %,.2f", item));
                    if (item.compareTo(BigDecimal.ZERO) < 0) {
                        setStyle("-fx-text-fill: red;");
                    } else {
                        setStyle("-fx-text-fill: green;");
                    }
                }
            }
        });
        
        tblLancamentos.setItems(lancamentos);
    }
    
    private void configurarEventos() {
        btnProcurar.setOnAction(e -> procurarArquivo());
        btnImportar.setOnAction(e -> importarArquivo());
        btnCancelar.setOnAction(e -> fecharJanela());
        btnSalvar.setOnAction(e -> salvarLancamentos());
        
        cbTipoArquivo.setOnAction(e -> validarArquivo());
    }
    
    private void inicializarInterface() {
        progressImportacao.setVisible(false);
        btnImportar.setDisable(true);
        btnSalvar.setDisable(true);
        lblStatus.setText("Selecione um arquivo para importar");
    }
    
    @FXML
    private void procurarArquivo() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Selecionar Arquivo de Extrato");
        
        // Configurar filtros baseado no tipo selecionado
        String tipoSelecionado = cbTipoArquivo.getValue();
        switch (tipoSelecionado) {
            case "CSV":
                fileChooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("Arquivos CSV", "*.csv"));
                break;
            case "OFX":
                fileChooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("Arquivos OFX", "*.ofx"));
                break;
            case "TXT":
                fileChooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("Arquivos TXT", "*.txt"));
                break;
        }
        
        fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Todos os arquivos", "*.*"));
        
        Stage stage = (Stage) btnProcurar.getScene().getWindow();
        arquivoSelecionado = fileChooser.showOpenDialog(stage);
        
        if (arquivoSelecionado != null) {
            txtArquivo.setText(arquivoSelecionado.getAbsolutePath());
            validarArquivo();
        }
    }
    
    private void validarArquivo() {
        if (arquivoSelecionado == null || !arquivoSelecionado.exists()) {
            btnImportar.setDisable(true);
            lblStatus.setText("Arquivo não encontrado");
            return;
        }
        
        String tipoArquivo = cbTipoArquivo.getValue();
        boolean valido = importacaoService.validarFormatoArquivo(
            arquivoSelecionado.getAbsolutePath(), tipoArquivo);
        
        if (valido) {
            btnImportar.setDisable(false);
            lblStatus.setText("Arquivo válido - Pronto para importar");
        } else {
            btnImportar.setDisable(true);
            lblStatus.setText("Formato de arquivo inválido");
        }
    }
    
    @FXML
    private void importarArquivo() {
        if (arquivoSelecionado == null) {
            AlertUtil.mostrarAviso("Validação", "Selecione um arquivo para importar.");
            return;
        }
        
        btnImportar.setDisable(true);
        progressImportacao.setVisible(true);
        lblStatus.setText("Importando arquivo...");
        
        Task<List<LancamentoBancario>> task = new Task<List<LancamentoBancario>>() {
            @Override
            protected List<LancamentoBancario> call() throws Exception {
                String tipoArquivo = cbTipoArquivo.getValue();
                String caminhoArquivo = arquivoSelecionado.getAbsolutePath();
                
                updateProgress(0.2, 1.0);
                
                List<LancamentoBancario> resultado;
                switch (tipoArquivo) {
                    case "CSV":
                        resultado = importacaoService.importarCSV(caminhoArquivo);
                        break;
                    case "OFX":
                        resultado = importacaoService.importarOFX(caminhoArquivo);
                        break;
                    case "TXT":
                        resultado = importacaoService.importarTXT(caminhoArquivo);
                        break;
                    default:
                        throw new IllegalArgumentException("Tipo de arquivo não suportado: " + tipoArquivo);
                }
                
                updateProgress(1.0, 1.0);
                return resultado;
            }
            
            @Override
            protected void succeeded() {
                List<LancamentoBancario> resultado = getValue();
                lancamentos.clear();
                lancamentos.addAll(resultado);
                
                atualizarEstatisticas();
                
                btnImportar.setDisable(false);
                progressImportacao.setVisible(false);
                btnSalvar.setDisable(false);
                lblStatus.setText(String.format("Importação concluída - %d registros", resultado.size()));
                
                AlertUtil.mostrarInformacao("Sucesso", 
                    String.format("Arquivo importado com sucesso!\n%d registros encontrados.", resultado.size()));
            }
            
            @Override
            protected void failed() {
                btnImportar.setDisable(false);
                progressImportacao.setVisible(false);
                lblStatus.setText("Erro na importação");
                
                AlertUtil.mostrarErro("Erro na Importação", 
                    "Não foi possível importar o arquivo.", getException().getMessage());
            }
        };
        
        progressImportacao.progressProperty().bind(task.progressProperty());
        new Thread(task).start();
    }
    
    private void atualizarEstatisticas() {
        int totalRegistros = lancamentos.size();
        
        BigDecimal totalCreditos = lancamentos.stream()
            .filter(l -> l.getValor().compareTo(BigDecimal.ZERO) > 0)
            .map(LancamentoBancario::getValor)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        BigDecimal totalDebitos = lancamentos.stream()
            .filter(l -> l.getValor().compareTo(BigDecimal.ZERO) < 0)
            .map(LancamentoBancario::getValor)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        lblTotalRegistros.setText(String.valueOf(totalRegistros));
        lblTotalCreditos.setText(String.format("R$ %,.2f", totalCreditos));
        lblTotalDebitos.setText(String.format("R$ %,.2f", totalDebitos.abs()));
    }
    
    @FXML
    private void salvarLancamentos() {
        if (lancamentos.isEmpty()) {
            AlertUtil.mostrarAviso("Validação", "Não há lançamentos para salvar.");
            return;
        }
        
        if (AlertUtil.mostrarConfirmacao("Salvar", 
            String.format("Deseja salvar %d lançamentos?", lancamentos.size()))) {
            
            // Implementar lógica de salvamento no banco de dados
            AlertUtil.mostrarInformacao("Sucesso", "Lançamentos salvos com sucesso!");
            fecharJanela();
        }
    }
    
    private void fecharJanela() {
        Stage stage = (Stage) btnCancelar.getScene().getWindow();
        stage.close();
    }
}
