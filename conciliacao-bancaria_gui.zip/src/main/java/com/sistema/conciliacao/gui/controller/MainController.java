package com.sistema.conciliacao.gui.controller;

import com.sistema.conciliacao.gui.util.AlertUtil;
import com.sistema.conciliacao.gui.util.SceneManager;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class MainController implements Initializable {
    
    @FXML private VBox mainContainer;
    @FXML private MenuBar menuBar;
    @FXML private MenuItem menuNovaConciliacao;
    @FXML private MenuItem menuImportarExtrato;
    @FXML private MenuItem menuRelatorios;
    @FXML private MenuItem menuSair;
    @FXML private MenuItem menuSobre;
    
    @FXML private Button btnNovaConciliacao;
    @FXML private Button btnImportarExtrato;
    @FXML private Button btnVisualizarConciliacoes;
    @FXML private Button btnRelatorios;
    @FXML private Button btnConfiguracoes;
    
    @FXML private Label lblUltimaConciliacao;
    @FXML private Label lblTotalConciliacoes;
    @FXML private Label lblPendencias;
    
    private SceneManager sceneManager;
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        sceneManager = SceneManager.getInstance();
        configurarEventos();
        atualizarDashboard();
    }
    
    private void configurarEventos() {
        // Menu
        menuNovaConciliacao.setOnAction(e -> abrirNovaConciliacao());
        menuImportarExtrato.setOnAction(e -> abrirImportacaoExtrato());
        menuRelatorios.setOnAction(e -> abrirRelatorios());
        menuSair.setOnAction(e -> sair());
        menuSobre.setOnAction(e -> mostrarSobre());
        
        // Botões principais
        btnNovaConciliacao.setOnAction(e -> abrirNovaConciliacao());
        btnImportarExtrato.setOnAction(e -> abrirImportacaoExtrato());
        btnVisualizarConciliacoes.setOnAction(e -> abrirVisualizacaoConciliacoes());
        btnRelatorios.setOnAction(e -> abrirRelatorios());
        btnConfiguracoes.setOnAction(e -> abrirConfiguracoes());
    }
    
    @FXML
    private void abrirNovaConciliacao() {
        try {
            sceneManager.abrirJanela("/fxml/NovaConciliacao.fxml", "Nova Conciliação", 900, 600);
        } catch (Exception e) {
            AlertUtil.mostrarErro("Erro", "Não foi possível abrir a tela de nova conciliação.", e.getMessage());
        }
    }
    
    @FXML
    private void abrirImportacaoExtrato() {
        try {
            sceneManager.abrirJanela("/fxml/ImportacaoExtrato.fxml", "Importar Extrato", 800, 500);
        } catch (Exception e) {
            AlertUtil.mostrarErro("Erro", "Não foi possível abrir a tela de importação.", e.getMessage());
        }
    }
    
    @FXML
    private void abrirVisualizacaoConciliacoes() {
        try {
            sceneManager.abrirJanela("/fxml/ListaConciliacoes.fxml", "Conciliações", 1000, 700);
        } catch (Exception e) {
            AlertUtil.mostrarErro("Erro", "Não foi possível abrir a lista de conciliações.", e.getMessage());
        }
    }
    
    @FXML
    private void abrirRelatorios() {
        try {
            sceneManager.abrirJanela("/fxml/Relatorios.fxml", "Relatórios", 900, 600);
        } catch (Exception e) {
            AlertUtil.mostrarErro("Erro", "Não foi possível abrir a tela de relatórios.", e.getMessage());
        }
    }
    
    @FXML
    private void abrirConfiguracoes() {
        try {
            sceneManager.abrirJanela("/fxml/Configuracoes.fxml", "Configurações", 600, 400);
        } catch (Exception e) {
            AlertUtil.mostrarErro("Erro", "Não foi possível abrir as configurações.", e.getMessage());
        }
    }
    
    private void sair() {
        if (AlertUtil.mostrarConfirmacao("Sair", "Deseja realmente sair do sistema?")) {
            Stage stage = (Stage) mainContainer.getScene().getWindow();
            stage.close();
        }
    }
    
    private void mostrarSobre() {
        AlertUtil.mostrarInformacao("Sobre", 
            "Sistema de Conciliação Bancária v1.0\n\n" +
            "Desenvolvido para automatizar o processo de conciliação\n" +
            "entre extratos bancários e registros internos.\n\n" +
            "© 2024 - Todos os direitos reservados");
    }
    
    private void atualizarDashboard() {
        // Simular dados do dashboard
        lblUltimaConciliacao.setText(LocalDate.now().minusDays(1).toString());
        lblTotalConciliacoes.setText("15");
        lblPendencias.setText("3");
    }
}
