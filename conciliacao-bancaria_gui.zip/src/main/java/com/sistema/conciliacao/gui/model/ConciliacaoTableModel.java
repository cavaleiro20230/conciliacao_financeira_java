package com.sistema.conciliacao.gui.model;

import javafx.beans.property.*;
import java.math.BigDecimal;
import java.time.LocalDate;

public class ConciliacaoTableModel {
    private final ObjectProperty<LocalDate> data = new SimpleObjectProperty<>();
    private final StringProperty descricao = new SimpleStringProperty();
    private final ObjectProperty<BigDecimal> valor = new SimpleObjectProperty<>();
    private final StringProperty tipoMatch = new SimpleStringProperty();
    private final ObjectProperty<BigDecimal> diferenca = new SimpleObjectProperty<>();
    private final StringProperty origem = new SimpleStringProperty();
    
    // Construtores
    public ConciliacaoTableModel() {}
    
    public ConciliacaoTableModel(LocalDate data, String descricao, BigDecimal valor, String origem) {
        setData(data);
        setDescricao(descricao);
        setValor(valor);
        setOrigem(origem);
    }
    
    // Getters e Setters para Data
    public LocalDate getData() { return data.get(); }
    public void setData(LocalDate data) { this.data.set(data); }
    public ObjectProperty<LocalDate> dataProperty() { return data; }
    
    // Getters e Setters para Descrição
    public String getDescricao() { return descricao.get(); }
    public void setDescricao(String descricao) { this.descricao.set(descricao); }
    public StringProperty descricaoProperty() { return descricao; }
    
    // Getters e Setters para Valor
    public BigDecimal getValor() { return valor.get(); }
    public void setValor(BigDecimal valor) { this.valor.set(valor); }
    public ObjectProperty<BigDecimal> valorProperty() { return valor; }
    
    // Getters e Setters para Tipo de Match
    public String getTipoMatch() { return tipoMatch.get(); }
    public void setTipoMatch(String tipoMatch) { this.tipoMatch.set(tipoMatch); }
    public StringProperty tipoMatchProperty() { return tipoMatch; }
    
    // Getters e Setters para Diferença
    public BigDecimal getDiferenca() { return diferenca.get(); }
    public void setDiferenca(BigDecimal diferenca) { this.diferenca.set(diferenca); }
    public ObjectProperty<BigDecimal> diferencaProperty() { return diferenca; }
    
    // Getters e Setters para Origem
    public String getOrigem() { return origem.get(); }
    public void setOrigem(String origem) { this.origem.set(origem); }
    public StringProperty origemProperty() { return origem; }
}
