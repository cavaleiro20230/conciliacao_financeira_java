package com.sistema.conciliacao.gui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class ConciliacaoApplication extends Application {
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/MainWindow.fxml"));
        Scene scene = new Scene(loader.load(), 1200, 800);
        
        // Aplicar CSS
        scene.getStylesheets().add(getClass().getResource("/css/styles.css").toExternalForm());
        
        primaryStage.setTitle("Sistema de Conciliação Bancária");
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(1000);
        primaryStage.setMinHeight(700);
        
        // Ícone da aplicação
        try {
            primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("/images/bank-icon.png")));
        } catch (Exception e) {
            // Ícone não encontrado, continuar sem ele
        }
        
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
