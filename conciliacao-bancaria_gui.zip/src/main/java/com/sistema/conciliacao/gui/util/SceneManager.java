package com.sistema.conciliacao.gui.util;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class SceneManager {
    private static SceneManager instance;
    
    private SceneManager() {}
    
    public static SceneManager getInstance() {
        if (instance == null) {
            instance = new SceneManager();
        }
        return instance;
    }
    
    public void abrirJanela(String fxmlPath, String titulo, double largura, double altura) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
        Scene scene = new Scene(loader.load(), largura, altura);
        
        // Aplicar CSS
        scene.getStylesheets().add(getClass().getResource("/css/styles.css").toExternalForm());
        
        Stage stage = new Stage();
        stage.setTitle(titulo);
        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setResizable(true);
        stage.show();
    }
    
    public void abrirJanelaModal(String fxmlPath, String titulo, double largura, double altura, Stage owner) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
        Scene scene = new Scene(loader.load(), largura, altura);
        
        scene.getStylesheets().add(getClass().getResource("/css/styles.css").toExternalForm());
        
        Stage stage = new Stage();
        stage.setTitle(titulo);
        stage.setScene(scene);
        stage.initModality(Modality.WINDOW_MODAL);
        stage.initOwner(owner);
        stage.setResizable(false);
        stage.showAndWait();
    }
    
    public <T> T abrirJanelaComController(String fxmlPath, String titulo, double largura, double altura) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
        Scene scene = new Scene(loader.load(), largura, altura);
        
        scene.getStylesheets().add(getClass().getResource("/css/styles.css").toExternalForm());
        
        Stage stage = new Stage();
        stage.setTitle(titulo);
        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
        
        return loader.getController();
    }
}
