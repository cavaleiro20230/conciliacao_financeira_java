module conciliacao.bancaria {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    
    exports com.sistema.conciliacao.gui;
    exports com.sistema.conciliacao.gui.controller;
    exports com.sistema.conciliacao.gui.model;
    exports com.sistema.conciliacao.gui.util;
    exports com.sistema.conciliacao.model;
    exports com.sistema.conciliacao.service;
    exports com.sistema.conciliacao.util;
    exports com.sistema.conciliacao.exception;
}
